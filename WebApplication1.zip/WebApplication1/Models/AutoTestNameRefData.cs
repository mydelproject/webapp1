﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public partial class AutoTestNameRefData
    {
        public string ScriptName { get; set; }
        public int Sno { get; set; }
    }
}
